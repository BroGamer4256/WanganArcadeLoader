--------------------------------
---- setting.lua
--------------------------------

mCalibHandleCenter = 32512
mCalibAccelCenter = 0
mCalibBrakeCenter = 0
mCalibMotorCenter = 511
mCalibTouchLeft = 2048
mCalibTouchRight = 14336
mCalibTouchTop = 14336
mCalibTouchBottom = 2048
mCoinChute = 1
mBuyCardCost = 3
mGameCost = 1
mContinueCost = 1
mFullCourseCost = 1
mFreePlay = 1
mPcbId = 0
mIcCardRw = 1
mIcCardVender = 0
mMgCardRw = 1
mForceFeedback = 1
mWinsAndRemains = 1
mEventMode = 0
mEventModeDist = 0
mEventModeCount = 4
mEventMode2on2 = 0
mCloseType = 2
mCloseSun = 96
mCloseMon = 96
mCloseTue = 96
mCloseWed = 96
mCloseThu = 96
mCloseFri = 96
mCloseSat = 96
mCloseDay = 96
mTouchPanel = 1
mGameVol = 10
mAttractVol = 10
mClockOffset = 0
mTimeZoneType = 36
mTimeDayLight = 0
mTimeZoneHourOffset = 8
mTimeZoneMinOffset = 0
mSummerTimeHourOffset = 0
mSummerTimeMinOffset = 0
mTournamentMode = 0
mTournamentHoldYear = 2016
mTournamentHoldMonth = 1
mTournamentHoldDay = 1
mTournamentEntryHour = 1
mTournamentEntryMinute = 0
mTournamentHoldHour = 12
mTournamentholdMinute = 0
mTournamentCompetitionNum = 4
mTournamentParticipantNum = 16
--------------------------------
---- EOF
--------------------------------
